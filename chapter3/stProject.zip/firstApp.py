import datetime
from flask import Flask
from flask import request
app = Flask(__name__)

@app.route("/csstudent/<name>")
def showStudentName(name):
    return f"Hello {name}, you are a fine Computer Science student!"

@app.route("/csstudent/<firstName>/<lastName>")
def showStudentFullName(firstName, lastName):
    return f"Hello {firstName} {lastName}, you are a fine Computer Science student!"

@app.route("/csstudent/<name>/birthyear/<int:birthyear>")
def showStudentNameAndAge(name, birthyear):
    age = datetime.date.today().year - birthyear
    return f"{name}, born {age} years ago, is a fine CS student!"

@app.route("/csstudent/<name>/heightInInches/<float:height>")
def showStudentNameAndHeight(name, height):
    #convert height in inches to whole feet and inches
    feet = height // 12
    inches = height % 12
    return f"{name} is a {int(feet)}'{inches}\" tall fine CS student!"

@app.route("/csstudent", methods = ["POST"])
def postData():
    name = request.form["name"]
    age = request.form["age"]

    return f"{name} is {age} years old and is a fine CS student!"

@app.route("/csstudent")
def showStudentNameAndAgeFromQueryParams():
    name = request.args.get("name")
    age = int(request.args.get("age"))

    return f"{name} is {age} years old and is a fine CS student!"

@app.route("/csstudent/getAge", methods = ["POST"])
def get_age_in_future():
    currentAge = int(request.form["age"])
    additionalYears = int(request.form["additionalYears"])

    retVal = {"originalAge": currentAge, "newAge": (currentAge + additionalYears)}
    return retVal
